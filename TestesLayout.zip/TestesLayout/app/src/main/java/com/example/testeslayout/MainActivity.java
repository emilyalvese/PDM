package com.example.testeslayout;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imagens = new Integer[] {R.drawable.happy,
        R.drawable.cachorro,R.drawable.garden,
        R.drawable.patinho,R.drawable.porquinho};

        imgFoto.setImageResource(imagens[posicao]);

    }
}