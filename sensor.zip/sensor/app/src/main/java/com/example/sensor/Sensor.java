package com.example.sensor;

public class Sensor {
}
