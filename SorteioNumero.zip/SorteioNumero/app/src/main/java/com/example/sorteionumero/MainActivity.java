package com.example.sorteionumero;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    EditText numMin, numMax;
    TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvResultado=findViewById(R.id.textView);
        numMax=findViewById(R.id.editTextTextPersonName);
        numMin=findViewById(R.id.editTextTextPersonName3);
    }

    public void sorteiaNumero(View v){
        int maximo=Integer.parseInt(numMax.getText().toString());
        int minimo=Integer.parseInt(numMin.getText().toString());

        int numeroSorteado=(int) Math.random()*(maximo-minimo+1)+minimo;
        tvResultado.setText(Integer.toString(numeroSorteado));

    }
}