package com.example.listagemlistview;

public class ItemChurrasco {
    int id;
    String nome;
    int imagem;

    public ItemChurrasco(int id, String nome, int imagem) {
        this.id = id;
        this.nome = nome;
        this.imagem = imagem;
    }
}