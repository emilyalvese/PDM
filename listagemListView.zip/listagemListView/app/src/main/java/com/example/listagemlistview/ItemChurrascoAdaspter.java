package com.example.listagemlistview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ItemChurrascoAdaspter extends ArrayAdapter<ItemChurrasco> {

    Context mContext;
    int mResource;


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(mResource, parent, false);

        TextView txtNome = convertView.findViewById(R.id.txt2);
        TextView txtId = convertView.findViewById(R.id.txt1);
        ImageView txtImagem = convertView.findViewById(R.id.imageView);

        //falta arrumar
        txtNome.setText(getItem(position).nome);
        txtId.setText(String.valueOf(getItem(position).id));
        txtImagem.setImageResource(getItem(position).imagem);

        return convertView;
        // return super.getView(position, convertView, parent);
    }

    public ItemChurrascoAdaspter(@NonNull Context context, int resource, @NonNull List<ItemChurrasco> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

}