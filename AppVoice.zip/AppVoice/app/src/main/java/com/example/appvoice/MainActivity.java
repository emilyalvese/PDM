package com.example.appvoice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.EditText;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    private TextToSpeech voz;
    private boolean vozCarregada = false;
    private EditText texto;
    private String fala;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        voz = new TextToSpeech(this, this);
        texto = findViewById(R.id.txtVoz);
    }

    @Override
    public void onInit(int status) {
        if(status==TextToSpeech.SUCCESS){
            voz.setLanguage(Locale.getDefault());
            vozCarregada = true;
        }
    }

    public void falar(View view){
        fala = texto.getText().toString();

        if(vozCarregada) {
            voz.speak(fala, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }
}