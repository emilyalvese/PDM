package com.example.database;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    SQLiteDatabase sqLitedb;
    ListView listview;
    EditText editText1;
    String nome;

    @SuppressLint({"Range"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listview = findViewById(R.id.listview);
        editText1 = findViewById(R.id.editText1);

        sqLitedb = openOrCreateDatabase("meubd", MODE_PRIVATE, null);
        sqLitedb.execSQL("CREATE TABLE IF NOT EXISTS usr (id INTEGER PRIMARY KEY AUTOINCREMENT," + " nome VARCHAR);");

        listar();
    }

    @SuppressLint("Range")
    public void inserir(View view){
        nome = editText1.getText().toString();
        ContentValues cv = new ContentValues();
        cv.put("nome", nome);
        sqLitedb.insert("usr ",null,cv);

        listar();
    }
    public void atualizar(View view){
        nome = editText1.getText().toString();
        ContentValues cv = new ContentValues();
        cv.put("nome", nome);
        sqLitedb.update("usr ", cv, "nome = ?", new String[]{String.valueOf(nome)});

        listar();
    }

    public void excluir(View view){
        sqLitedb.delete("usr ", "nome = ?", new String[]{String.valueOf(nome)});

        listar();
    }

    @SuppressLint("Range")
    public void listar(){
        sqLitedb.rawQuery("SELECT * FROM usr",null);
        Cursor c = sqLitedb.rawQuery("SELECT * FROM usr ",null);
        c.moveToFirst();
        ArrayList<String> listaUsuario = new ArrayList<>();

        while(!c.isAfterLast()){
            listaUsuario.add(c.getString(c.getColumnIndex("nome")));
            Log.d("tableusr", c.getString(c.getColumnIndex("id"))+c.getString(c.getColumnIndex("nome")));
            c.moveToNext();
        }

        ArrayAdapter<String> arayAdpter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, android.R.id.text1, listaUsuario);
        listview.setAdapter(arayAdpter);
    }
}