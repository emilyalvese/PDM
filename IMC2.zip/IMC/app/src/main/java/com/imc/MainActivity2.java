package com.imc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity2 extends AppCompatActivity {

    public String nome;
    public Double imc;
    private EditText txtNome;
    private EditText txtIMC;
    private ImageView imgView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent it = getIntent();
        nome = it.getStringExtra("nome");
        imc = it.getDoubleExtra("imc", 0);
        txtNome = findViewById(R.id.txtNome2);
        txtIMC = findViewById(R.id.txtImc2);
        imgView2 = findViewById(R.id.imgView2);

        txtNome.setText(nome);
        txtIMC.setText(imc.toString());
    }

    public void calcIMC() {
        if(imc < 18.5) {
            imgView2.setImageResource(R.drawable.abaixopeso);
        } else if (imc >= 18.5 && imc < 24.9 ) {
            imgView2.setImageResource(R.drawable.normal);
        } else if (imc >= 25 && imc < 29.9) {
            imgView2.setImageResource(R.drawable.sobrepeso);
        } else if (imc >= 30 && imc < 34.9) {
            imgView2.setImageResource(R.drawable.obesidade1);
        } else if (imc >= 35 && imc < 39.9) {
            imgView2.setImageResource(R.drawable.obesidade2);
        } else {
            imgView2.setImageResource(R.drawable.obesidade3);
        }
    }
}