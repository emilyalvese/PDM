package com.imc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    private EditText lblNome, lblPeso, lblAltura;
    private TextInputEditText hintIMC;
    private Double imc, peso, altura;
    private String nome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lblNome = findViewById(R.id.lblNome);
        lblAltura = findViewById(R.id.lblAltura);
        lblPeso = findViewById(R.id.lblPeso);

        nome = lblNome.getText().toString();
        hintIMC = findViewById(R.id.hintIMC);

    }

    public void calcular (View calcular){
        peso = Double.parseDouble(lblPeso.getText().toString());
        altura = Double.parseDouble(lblAltura.getText().toString());
        imc = peso/(altura*altura);

        Intent itTela = new Intent(this, MainActivity2.class);
        itTela.putExtra("nome", nome);
        itTela.putExtra("imc", imc);

        startActivity(itTela);
    }

}