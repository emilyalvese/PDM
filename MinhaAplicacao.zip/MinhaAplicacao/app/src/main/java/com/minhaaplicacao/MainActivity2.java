package com.minhaaplicacao;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView tvContador;
    Button button;
    int i=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        button =findViewById(R.id.button);
        tvContador =findViewById(R.id.textView);

        tvContador.setText("blablabla");
    }

    public void contagem(View v){
        i++;
        tvContador.setText(Integer.toString(i));
    }

}