package com.example.database.model;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class NotaDAO {

    SQLiteDatabase db;

    public NotaDAO(Context context){
        db = context.openOrCreateDatabase("db", 0, null);
        // ++ query
    }

    public void inserirNota(Nota nota){

    }

    public void excluirNota(Nota nota){

    }

    public Nota getNOta(int id){

        return null;
    }

    public ArrayList<Nota> listarNotas(){

        return null;
    }
}
