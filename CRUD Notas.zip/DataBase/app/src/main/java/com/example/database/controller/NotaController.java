package com.example.database.controller;

import android.content.Context;

import com.example.database.model.Nota;
import com.example.database.model.NotaDAO;

import java.util.ArrayList;

public class NotaController {

    NotaDAO notaDAO;

    public NotaController(Context c){
        notaDAO = new NotaDAO(c);
    }

    public void cadastrarNota(Nota nota){
        if (nota.getTitulo().length()>3){
            notaDAO.inserirNota(nota);
        }
    }

    public Nota getNota(int idNota){
        return notaDAO.getNOta(idNota);
    }

    public void excluirNota(Nota nota){
        notaDAO.excluirNota(nota);
    }

    public ArrayList<Nota> recuperaNotas(){
        return notaDAO.listarNotas();
    }

    public ArrayList<String> recuperaTituloNtas(){
        ArrayList<String> tituloNotas = new ArrayList<>();
        for(Nota n:this.recuperaNotas()){
            tituloNotas.add(n.getTitulo());
        }
        return tituloNotas;
    }
}